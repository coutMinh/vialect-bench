from pathlib import Path
import json
import subprocess
import sys
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
slugs = (
    "qwen_2_5_0_5b_instruct", "qwen_2_5_3b_instruct", "qwen_2_5_7b_instruct",
    "llama_3_1_8b_instruct", "mistral_7b_instruct_v0_3", "gemma_2_9b_it",
    "gemma_3_4b_it", "vistral_7b_chat", "seallm_7b_chat", "gpt_4o",
)
output_dir = root / "outputs/normalized_direct_prompting_full"
log_dir = root / "logs"
output_dir.mkdir(parents=True, exist_ok=True)
log_dir.mkdir(parents=True, exist_ok=True)
status_path = root / "queue_status.json"

def status(**kwargs):
    payload = {"updated_utc": datetime.now(timezone.utc).isoformat(), **kwargs}
    status_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

for slug in slugs:
    module = "src.probe_openai" if slug == "gpt_4o" else (
        "src.probe_gemma3" if slug == "gemma_3_4b_it" else "src.probe_models"
    )
    output_path = output_dir / f"{slug}.jsonl"
    command = [
        sys.executable, "-u", "-m", module,
        "--config", f"configs/direct_prompting/{slug}.yaml",
        "--cases", "full_normalized_cases.jsonl",
        "--output", str(output_path),
        "--prompt-strategy", "normalized_direct",
    ]
    status(state="running", model=slug, output=str(output_path))
    with (log_dir / f"{slug}.log").open("a", encoding="utf-8") as log:
        log.write("START " + datetime.now(timezone.utc).isoformat() + "\n")
        log.flush()
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
        log.write("EXIT " + str(result.returncode) + "\n")
    if result.returncode:
        status(state="failed", model=slug, exit_code=result.returncode)
        raise SystemExit(result.returncode)
    rows = [json.loads(line) for line in output_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(rows) != 2400 or any(not str(row.get("raw_output") or "").strip() for row in rows):
        status(state="invalid", model=slug, rows=len(rows))
        raise SystemExit(f"Invalid completed output for {slug}: {len(rows)} rows")
    status(state="completed_model", model=slug, rows=len(rows))
status(state="complete", models=len(slugs), rows=24000)
